import React from 'react';
import { View, Text } from 'react-native';
import IconConfig from '../geiger_iconsConfig.json'; // with json-loader

export const Icon = ({ name }) => {
  return (
    <View style={{ width: 24, height: 24 }}>
      <Text style={{ color: '#FFF', fontSize: 24, lineHeight: 24, fontFamily: 'geiger_icons', fontWeight: 'normal', fontStyle: 'normal' }}>
        {unescape(String(IconConfig['icons'][name]))}
      </Text>
    </View>
  );
};

export enum IconName {
  EYE = 'eye',
  UNLOCK = 'unlock',
  USERICON = 'userIcon',
}