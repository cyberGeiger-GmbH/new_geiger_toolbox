import 'package:flutter/widgets.dart';

class IconExample extends StatelessWidget {
  IconExample({ Key? key, required this.name }) : super(key: key);

  final IconName name;

  @override
  Widget build(BuildContext context) {
    return Text(
      String.fromCharCodes(IconMap.get(name.str)),
      style: TextStyle(fontSize: 24, fontFamily: 'geiger_icons', height: 1, fontWeight: FontWeight.normal},
    );
  }
}

enum IconName {
  EYE,
  UNLOCK,
  USERICON,
}

extension IconNameExtension on IconName {
  String get str {
    return describeEnum(this).toLowerCase().replaceAll('_', '-');
  }
}

class IconMap {
  static const Map<String, List<int>> _data = {
    'eye': [57739, 57394],
    'unlock': [57344, 58146, 59425, 57533],
    'userIcon': [57344, 61416, 58386, 57357],
  };

  static List<int> get(String key) {
    return _data[key]!;
  }
}